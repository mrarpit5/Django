# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.http import HttpResponse
from django.shortcuts import render
from .models import data
from .models import info
	
# Create your views here.
def index(request):
	d=data.objects.all()
	i=info.objects.all()
	return render(request,"finalapp/index.html",{'d':d,'i':i})
