# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin

# Register your models here.
from finalapp.models import data
from finalapp.models import info
admin.site.register(data)
admin.site.register(info)



