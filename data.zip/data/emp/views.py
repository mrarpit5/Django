# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.http import HttpResponse
from django.shortcuts import render
from .models import basic
from .models import detail

# Create your views

def index(request):
	q=basic.objects.all()
	a=detail.objects.all()
	return render(request,"emp/index.html",{'q':q,'a':a})
