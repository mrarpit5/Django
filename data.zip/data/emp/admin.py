# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin

# Register your models here.
from emp.models import basic
from emp.models import detail
admin.site.register(basic)
admin.site.register(detail)
