# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.http import HttpResponse
from django.shortcuts import render
from app.models import data
from app.models import detail
# Create your views here.

def index(request):
	d=data.objects.all()
	s=detail.objects.all()
	return render(request,'app/index.html',{'d':d,'s':s})
	

