# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin

# Register your models here.
from app.models import data
from app.models import detail

admin.site.register(data)
admin.site.register(detail)










