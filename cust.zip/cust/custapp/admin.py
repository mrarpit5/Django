# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from custapp.models import cu
from custapp.models import cus
admin.site.register(cu)
admin.site.register(cus)
# Register your models here.
