# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.http import HttpResponse
from django.shortcuts import render
from .models import cu
from .models import cus

def index(request):

	d=cu.objects.all()
	e=cus.objects.all()
	return render(request,'custapp/index.html',{'d':d,'e':e})
# Create your views here.
