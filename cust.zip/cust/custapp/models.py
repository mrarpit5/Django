# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

# Create your models here.
class cu(models.Model):
	name=models.CharField(max_length=20)
class cus(models.Model):
	n=models.ForeignKey(cu,on_delete=models.CASCADE)
	add=models.CharField(max_length=20)

